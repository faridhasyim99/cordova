<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect('localhost', 'id12794777_admin', 'admin123', 'id12794777_akademik') or die ("could not connect database");
?>